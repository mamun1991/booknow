<?php
// src/Service/WebSocketConnectorFactory.php

namespace App\Service;

class NotificationHandlerFactory
{
    public static function create(string $sharedFilePath)
    {
        return new \App\WebSocket\NotificationHandler($sharedFilePath);
    }
}